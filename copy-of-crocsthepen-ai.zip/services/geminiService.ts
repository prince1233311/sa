
import { GoogleGenAI, Part, Modality, VideoGenerationReferenceType, Tool } from "@google/genai";
import { ChatMode, MessagePart, Message } from "../types";

export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const getAI = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY as string });
};

const transformPart = (part: MessagePart): Part | null => {
  if (part.text) return { text: part.text };
  
  if (part.inlineData && part.inlineData.data) {
    const cleanData = part.inlineData.data.includes(',') 
      ? part.inlineData.data.split(',')[1] 
      : part.inlineData.data;
      
    if (!cleanData) return null;

    return {
      inlineData: {
        mimeType: part.inlineData.mimeType,
        data: cleanData
      }
    };
  }
  return null;
};

const getSystemInstruction = (mode: ChatMode): string => {
  switch (mode) {
    case 'code':
      return "You are a senior staff software engineer at a top tech firm. You write robust, clean, and highly performant code. Prefer TypeScript, React, and Tailwind CSS. Always provide a brief architectural overview of your solution.";
    case 'image':
      return "You are a world-class visual director. You help users conceive high-quality artistic concepts. Use vivid, descriptive language to help craft detailed prompts for AI image generation.";
    default:
      return "You are CrocSthepen AI, a premium intelligence engine. You are helpful, sophisticated, and articulate. You have real-time access to Google Search to ensure your knowledge is current.";
  }
};

export const generateAIResponseStream = async function* (
  prompt: string, 
  history: Message[], 
  mode: ChatMode,
  userParts?: MessagePart[],
  useProModel: boolean = false
) {
  const ai = getAI();
  const model = useProModel ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
  
  const tools: Tool[] | undefined = mode === 'general' ? [{ googleSearch: {} }] : undefined;

  let contents = history.slice(-10).map(msg => {
    let parts: Part[] = [];
    if (msg.parts && msg.parts.length > 0) {
      msg.parts.forEach(p => {
        const transformed = transformPart(p);
        if (transformed) parts.push(transformed);
      });
    } else {
      parts.push({ text: msg.content });
    }
    return {
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: parts
    };
  });

  if (contents.length === 0 && prompt) {
     contents.push({
         role: 'user',
         parts: [{ text: prompt }]
     });
  }

  const responseStream = await ai.models.generateContentStream({
    model: model,
    contents: contents,
    config: {
      systemInstruction: getSystemInstruction(mode),
      tools: tools,
      temperature: 0.7,
      topP: 0.95
    }
  });

  for await (const chunk of responseStream) {
    yield chunk;
  }
};

export const processImageRequest = async (prompt: string, inputImage?: { base64: string, mimeType: string }, usePro: boolean = false): Promise<string> => {
  const ai = getAI();
  // Using gemini-3-pro-image-preview for Pro users
  const model = usePro ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';

  try {
    const parts: Part[] = [];
    if (inputImage) {
      parts.push({
        inlineData: {
          mimeType: inputImage.mimeType,
          data: inputImage.base64
        }
      });
    }
    parts.push({ text: prompt });

    const response = await ai.models.generateContent({
      model: model,
      contents: { parts },
      config: {
        imageConfig: { 
          aspectRatio: "1:1",
          imageSize: usePro ? "1K" : undefined
        }
      }
    });

    const respParts = response.candidates?.[0]?.content?.parts;
    if (respParts) {
      for (const part of respParts) {
        if (part.inlineData) {
          return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
      }
    }
    
    throw new Error("Generation completed but no image was returned.");
  } catch (error) {
    console.error("Image Gen Error:", error);
    throw error;
  }
};

export const generateVideo = async (
  prompt: string, 
  aspectRatio: '16:9' | '9:16', 
  refImageBase64?: string, 
  refImageMimeType?: string
): Promise<string> => {
  const ai = getAI();
  const model = refImageBase64 ? 'veo-3.1-generate-preview' : 'veo-3.1-fast-generate-preview';
  
  const cleanBase64 = refImageBase64 && refImageBase64.includes(',') 
    ? refImageBase64.split(',')[1] 
    : refImageBase64;

  try {
    let operation;
    if (refImageBase64 && refImageMimeType) {
      operation = await ai.models.generateVideos({
        model: model,
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio,
          referenceImages: [{
            image: {
              imageBytes: cleanBase64!,
              mimeType: refImageMimeType
            },
            referenceType: