
import React from 'react';

export const APP_NAME = "CrocSthepen AI";
export const STARTING_CREDITS = 100;
export const COST_PER_MESSAGE = 1;
export const COST_PER_PRO_MESSAGE = 3;
export const COST_PER_IMAGE = 10;
export const COST_PER_WEBSITE = 25;
export const COST_PER_VIDEO = 50;
export const DAILY_REWARD_AMOUNT = 50;

export const Logo: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => (
  <div className={`flex items-center justify-center overflow-hidden rounded-[30%] shadow-xl bg-white border border-emerald-50 ${className}`}>
    <img 
      src="https://api.dicebear.com/7.x/shapes/svg?seed=CrocSthepen&backgroundColor=10b981" 
      alt="CrocSthepen Logo" 
      className="w-[80%] h-[80%] object-contain"
      onError={(e) => {
        e.currentTarget.src = "https://api.dicebear.com/7.x/bottts/svg?seed=CrocSthepen&backgroundColor=ffffff";
      }}
    />
  </div>
);

export const BRAND_CONFIG = {
  primary: "emerald-600",
  secondary: "indigo-600",
  dark: "gray-950",
  light: "white",
  accent: "emerald-400",
  gradient: "from-emerald-600 to-green-500"
};
